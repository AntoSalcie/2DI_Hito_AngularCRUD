export class Producto {
    id: Number = 0;
    nombre: String;
    precio: Number;
    unidades: Number;
}
