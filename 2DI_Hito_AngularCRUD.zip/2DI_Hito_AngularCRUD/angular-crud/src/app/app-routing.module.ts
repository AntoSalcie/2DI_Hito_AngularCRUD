import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { MostrarproductosComponent } from './mostrarproductos/mostrarproductos.component';
import { AppComponent } from './app.component';
import { ComponentesComponent } from './componentes/componentes.component';
import { CookiesComponent } from './cookies/cookies.component';
import { EjemploComponent } from './ejemplo/ejemplo.component';

const routes: Routes = [
  { path: '', component: MostrarproductosComponent },
  { path: 'mostrar', component: MostrarproductosComponent },
  { path: 'componente', component: ComponentesComponent },
  { path: 'cookies', component: CookiesComponent },
  { path: 'ejemplo', component: EjemploComponent},
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
