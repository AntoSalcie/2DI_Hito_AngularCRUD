import { Component, OnInit } from '@angular/core';
import { Producto } from '../models/producto';

@Component({
  selector: 'app-componentes',
  templateUrl: './componentes.component.html',
  styleUrls: ['./componentes.component.css']
})
export class ComponentesComponent implements OnInit {

  constructor() { }

  productosArray: Producto[] = [
    { id: 1, nombre: "Camiseta", precio: 12.44, unidades: 12 },
    { id: 2, nombre: "Pantalones", precio: 10.99, unidades: 1 },
    { id: 3, nombre: "Chaqueta", precio: 33.99, unidades: 18 },
  ];

  ngOnInit() {
    
  }

  displayedColumns: string[] = ['Id', 'Nombre', 'Precio', 'Unidades'];
  dataSource = this.productosArray;

}
